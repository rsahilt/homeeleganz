<div class="w-[250px] min-h-[400px] border-[1px] rounded-[35px] mx-auto relative">

    <img src="/images/sofa.jpeg" class="flex flex-col rounded-t-[35px]" />
    <div class="px-2 my-2 ">



        <div class="w-[100%] flex justify-between items-center text-[1.1em]">
            <span><b>Sofa set</b></span>
            <span class="text-red-600">$49.99</span>
        </div>
        <p class="text-[.8em] my-1 text-[#8A8A8A]">150x150x90</p>
        <p class="text-[.8em] my-1 text-[#8A8A8A]">Living room</p>
        <p class=" text-[.8em] my-1 mx-auto">Lorem Ipsum is simply dummy text of the printing
            and typesetting industry. Lorem Ipsum is simply dummy text of the printing
            and typesetting industry. </p>

    </div>
    <div class=" absolute bottom-1 right-0 left-0 flex justify-center">
        <button class="bg-black text-white text-[.7em] py-2 px-5 rounded-[20px] my-2 tracking-wider">ADD TO
            CART</button>
    </div>

</div><?php /**PATH C:\xampp\htdocs\homeeleganz\homeeleganz\resources\views/components/card.blade.php ENDPATH**/ ?>