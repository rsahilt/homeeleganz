<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

</head>


<body class="font-lato overflow-x-hidden">
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div id="title" class="font-lato text-center text-[1.5em] my-[1rem] tracking-wider uppercase">
        <h1><?php echo e($title); ?></h1>
    </div>

    <div class="categories-list mb-10">
        <ul class="h-[inherit]">
            <li class="hover:cursor-pointer">
                <a href="#">All Furnitures</a>
            </li>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="hover:cursor-pointer">
                    <a href="#"><?php echo e($category->name); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <div class="grid lg:grid-cols-4 md:grid-cols-3   gap-9">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-[250px] min-h-[400px] border-[1px] rounded-[35px] mx-auto relative">

            <img src="/images/sofa.jpeg" class="flex flex-col rounded-t-[35px]" />
            <div class="px-2 my-2 ">
                <div class="w-[100%] flex justify-between items-center text-[1.1em]">
                    <span><b><?php echo e($product->name); ?></b></span>
                    <span class="text-red-600">$<?php echo e($product->unit_price); ?></span>
                </div>
                <p class="text-[.8em] my-1 text-[#8A8A8A]"><?php echo e($product->dimensions); ?></p>
                <p class="text-[.8em] my-1 text-[#8A8A8A]"><?php echo e($product->catgeory_id); ?></p>
                <p class=" text-[.8em] my-1 mx-auto"><?php echo e($product->description); ?></p>
            </div>
            <div class=" absolute bottom-1 right-0 left-0 flex justify-center">
                <button class="bg-black text-white text-[.7em] py-2 px-5 rounded-[20px] my-2 tracking-wider">
                    <a href="/products/<?php echo e($product->id); ?>">View Product</a>
                </button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        

    </div>

    <div class="pagination"><?php echo e($products->links()); ?></div>
    

    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\homeeleganz\homeeleganz\resources\views/products.blade.php ENDPATH**/ ?>